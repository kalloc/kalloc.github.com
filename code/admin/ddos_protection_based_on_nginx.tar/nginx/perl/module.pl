use nginx;
use strict;
use warnings;
use IO::Socket::INET;

my ($socket,$data);
$socket = new IO::Socket::INET (PeerHost => '127.0.0.1',PeerPort => '5000',Proto => 'udp') ;
sub handler {
    my $r = shift;
    $socket->send($r->remote_addr()."\t".$r->uri()."\t".($r->header_in('Referer')|| '')."\t".($r->header_in('User-Agent') || ''));
    return DECLINED;
}

1;
__END__

