#!/usr/bin/perl

my $ttl=10;
my $file = '/var/log/nginx-redirect-fifo.log';
my $Tables = {};
my $Ban = {};
my $counter = 0;

my $result = "";
my $textbody = "";

my $ret,$run;
$flag=0;
opendir(PROC,"/proc") or die "Unable to open /proc:$!\n";
while (defined($_= readdir(PROC))){
        next if ($_ eq "." or $_ eq "..");
        next unless /^\d+$/; # filter out any random non-pid files
	open(PID,"/proc/$_/cmdline");
	my $cmd=<PID>;
	$flag+=1 if($cmd =~ m/\/parser_fifo.pl/);
	close(PID);
}
closedir(PROC);
exit(0) if($flag>2) ;



open (STAT,"< $file") || die;
open (BAN,"> /tmp/parser_fifo_ban") || die;


while  (<STAT>) {
    my $time=time();
    @item=split(/ /,$_);
    @item2=split(/\"/,$_);
    if( ! exists $Tables{$item[1]})  {
	$Tables{$item[1]}[1]=$time;
	$Tables{$item[1]}[0]=0;
    }

    next if( exists $Ban{$item[1]});
    
    if($item2[6]  =~ /America Online Browser|Linux 2.6.15-1.2054_FC5/) {
        $Tables{$item[1]}[0]+=6;
    } elsif($item2[6]  =~ /Debian-2.0.0.6-0etch1+lenny1|iOpus-I-M\; QXW03416\; .NET CLR 1.1.4322/) {
        $Tables{$item[1]}[0]+=4;  
    } else {
	$Tables{$item[1]}[0]++;
    }
    
    if($Tables{$item[1]}[1] + $ttl < $time) {
	delete $Tables{$item[1]};
    } elsif($Tables{$item[1]}[0] > 5) {
        system("pfctl -q -t ban  -T add  $item[1]");
        system("pfctl -q -k $item[1]");
	$Ban{$item[1]}=$time;
	print BAN "$item[1]\t$item2[1]\t$item2[5]\n";
	delete $Tables{$item[1]};
    }
    if($time % 60 == 0) {
	for $IPadr (keys(%Tables)) {
    	    delete $Tables{$IPadr} if ($Tables{$IPadr}[1] + 60 < $time);
	}
	for $IPadr (keys(%Ban)) {
    	    delete $Ban{$IPadr} if ($Ban{$IPadr} + 60 < $time);
	}
    }
}


